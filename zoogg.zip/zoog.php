<?php
include 'curl.php';
ulangi:
$nama = explode(" ", nama());
$nama1 = $nama[0];
$nama2 = $nama[1];
$email = strtolower($nama1.$nama2.random(3)."@getnada.com");
$curl = curl('https://zoogg.com/register?referrer=cSmlFNYSC');
$connect = fetch_value($curl,'connect.sid=',';');
$_csrf = fetch_value($curl,'_csrf=',';');
$token = fetch_value($curl,'<input type="hidden" name="_csrf" value="','"');
$data = '_csrf='.$token.'&email='.$email.'&password=error404&referrer=cSmlFNYSC';
$headers = [
'Host: zoogg.com',
'Content-Type: application/x-www-form-urlencoded',
'User-Agent: Mozilla/5.0 (Linux; U; Android 9; id-id; Redmi Note 8 Build/PKQ1.190616.001) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/71.0.3578.141 Mobile Safari/537.36 XiaoMi/MiuiBrowser/11.9.3-g',
'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
'Referer: https://zoogg.com/register?referrer=cSmlFNYSC',
'Cookie: _csrf='.$_csrf.'; connect.sid='.$connect,
];
$curl1 = curl('https://zoogg.com/register', $data, $headers);
if(strpos($curl1, 'Please check your email for verification.')){
echo color("green","[√] ")."Success Daftar | Email: ".$email."\n";
sleep(1);
echo color("yellow","[*] ")."Get link verifikasi\n";
sleep(3);
$get = curl('https://getnada.com/api/v1/inboxes/'.$email);
$uid = fetch_value($get,'"uid":"','"');
$nada = curl('https://getnada.com/api/v1/messages/'.$uid);
$link = fetch_value($nada,'<![endif]--><a href=\"','\"');
echo color("yellow","[*] ")."Verifikasi email\n";
sleep(3);
ulang:
$gass = curl($link);
if(strpos($gass, '502 Bad Gateway')){
goto ulang;
}else{
echo color("green","[√] ")."Success\n\n";
goto ulangi;
}
}else{
echo color("yellow","[×] ")."Failed Daftar\n\n";
goto ulangi;
}
